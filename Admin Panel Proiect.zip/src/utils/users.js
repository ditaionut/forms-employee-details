export const usersList = [
  {
    image:
      "https://www.loveyoursmile.dentist/wp-content/uploads/2019/10/restorative-dentistry-extractions.jpg",
    name: "John",
    email: "john@home.com",
    salary: 12000,
  },
  {
    image:
      "https://upload.wikimedia.org/wikipedia/commons/f/f5/Poster-sized_portrait_of_Barack_Obama.jpg",
    name: "David",
    email: "david@gmail.com",
    salary: 8500,
  },
];
